package com.example.david.unldavidpachecoapp;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Principal extends AppCompatActivity {
    Button botonCalcular;
    EditText centigrados;
    EditText faren;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("HolaMundo","Entramos en onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        botonCalcular = (Button) findViewById(R.id.btnCalcular);
        centigrados = (EditText) findViewById(R.id.txtCentigrados);
        faren = (EditText) findViewById(R.id.txtFaren);

        centigrados.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                double res;
                double num;
                num = Double.parseDouble(centigrados.getText().toString());
                res = (num * 1.8) + 32;
                faren.setText(""+ res);
                return false;
            }
        });

        faren.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                double res1;
                double aux;
                aux = Double.parseDouble(faren.getText().toString());
                res1 =(aux - 32) / 1.8;
                centigrados.setText("" + res1);
                return false;
            }
        });


    }
}
